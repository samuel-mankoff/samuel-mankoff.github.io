% restoredefaultpath;
% addpath( genpath( '..\Libraries\' ) );
% addpath('helper_functions\')
% addpath('mat\')
% addpath('other_functions\')

restoredefaultpath;
addpath(genpath('../Libraries/'));
addpath('helper_functions/');
addpath('mat/');
addpath('other_functions/');
