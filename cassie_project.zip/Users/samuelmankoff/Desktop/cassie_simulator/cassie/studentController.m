function tau = studentController(t, s, model, params)
% Modify this code to calculate the joint torques
% t - time
% s - state of the robot
% model - struct containing robot properties
% params - user defined parameters in studentParams.m
% tau - 10x1 vector of joint torques
% State vector components ID
q = s(1 : model.n);
dq = s(model.n+1 : 2*model.n);

%% [Control #2] High Gain Joint PD control on all actuated joints
kp = 500 ;
kd = 100 ;
x0 = getInitialState(model);
q0 = x0(1:model.n) ;
tau1 = -kp*(q(model.actuated_idx)-q0(model.actuated_idx)) - kd*dq(model.actuated_idx) ;

%%  [Control #3] COM Contact-Force based balancing
[r_com, v_com] = computeComPosVel(q, dq, model);
M = total_mass(model);
g = 9.81;
p = r_com;
% p = q(1:3); %pelvis
yaw   = q(4);
pitch = q(5);
roll   = q(6);
torso_pos = bodypos(model, 6, q);
R = torso_pos(1:3,1:3);

v = v_com;
euler_Rate = dq(4:6);
omega_body = [1, 0, -sin(pitch); 0, cos(roll), sin(pitch)*cos(roll); 0, -sin(roll), cos(pitch)*sin(roll)]*euler_Rate;
omega = R * omega_body;

p_des = [-0.0103; 0.0000; 0.8894];
% p_des = [0; 0; 1.0006]; %pelvis
euler_des = q0(4:6)';
R_des = rot_z(euler_des(1))*rot_y(euler_des(2))*rot_x(euler_des(3));

v_des = zeros(3,1);
omega_des = zeros(3,1);

e_p = p - p_des;
e_v = v - v_des;
R_e = R_des' * R;
e_R = 0.5 * [R_e(3,2) - R_e(2,3); R_e(1,3) - R_e(3,1); R_e(2,1) - R_e(1,2)];
e_w = omega - omega_des;

% Desired Wrench Formulation
kp_F = [-1000;-1000;-1400];
kv_F = [500;500;-700];
F_des  = kp_F.*e_p - kv_F.*e_v + (M)*g*[0;0;1];
kp_R = [10;170;50];
kv_R = [10;10;0];
Tau_des = kp_R.*e_R - kv_R.*e_w;
Wrench_des = [F_des ; Tau_des];

[p1, p2, p3, p4] = computeFootPositions(q, model);

% Moment Arm relative to COM
ma1 = p1 - r_com;
ma2 = p2 - r_com;
ma3 = p3 - r_com;
ma4 = p4 - r_com;

%Grasp Matrix
G = [ eye(3),      eye(3),      eye(3),      eye(3); 
    skew(ma1),    skew(ma2),    skew(ma3),    skew(ma4) ];

% Fc_opt = pinv(G)*Wrench_des;

X_foot1 = bodypos(model, model.idx.foot1, q) ;
X_foot2 = bodypos(model, model.idx.foot2, q) ;

pa1 = p1 - X_to_r(X_foot1);
pa2 = p2 - X_to_r(X_foot1);
pa3 = p3 - X_to_r(X_foot2);
pa4 = p4 - X_to_r(X_foot2);

G_foot1 = [ eye(3),      eye(3); 
 skew(pa1),    skew(pa2) ];

G_foot2= [ eye(3),      eye(3); 
 skew(pa3),    skew(pa4) ];


% Quadratic objective: 0.5*x'*x
H = 2*(G'*G + 0.004*eye(12));
f = -2*(G'*Wrench_des);
W = [G_foot1, zeros(6,6);
     zeros(6,6), G_foot2];

% left foot tau_y is row 5 of wrench
tauy_row_L = W(5,:);    % 1×12
H = H + (tauy_row_L' * tauy_row_L);

% right foot tau_y is row 11 (5 + 6)
tauy_row_R = W(11,:);   % 1×12
H = H + (tauy_row_R' * tauy_row_R);

% H = H+H2;
% f = f+f2;
z = -[0 0 1 0 0 0 0 0 0 0 0 0;
      0 0 0 0 0 1 0 0 0 0 0 0;
      0 0 0 0 0 0 0 0 1 0 0 0;
      0 0 0 0 0 0 0 0 0 0 0 1;];

mu = 0.8;
friction = [
    % Foot 1
     1  0  -mu   0 0 0   0 0 0   0 0 0
    -1  0  -mu   0 0 0   0 0 0   0 0 0
     0  1  -mu   0 0 0   0 0 0   0 0 0
     0 -1  -mu   0 0 0   0 0 0   0 0 0

    % Foot 2
     0 0 0   1  0  -mu   0 0 0   0 0 0
     0 0 0  -1  0  -mu   0 0 0   0 0 0
     0 0 0   0  1  -mu   0 0 0   0 0 0
     0 0 0   0 -1  -mu   0 0 0   0 0 0

    % Foot 3
     0 0 0   0 0 0   1  0  -mu   0 0 0
     0 0 0   0 0 0  -1  0  -mu   0 0 0
     0 0 0   0 0 0   0  1  -mu   0 0 0
     0 0 0   0 0 0   0 -1  -mu   0 0 0

    % Foot 4
     0 0 0   0 0 0   0 0 0   1  0  -mu
     0 0 0   0 0 0   0 0 0  -1  0  -mu
     0 0 0   0 0 0   0 0 0   0  1  -mu
     0 0 0   0 0 0   0 0 0   0 -1  -mu
];

% Inequality constraints (z constraints + friction cones)
Aineq = [z; friction];
bineq = zeros(size(Aineq,1),1);
Aeq = [];
beq = [];

%%  Optimizarion(Solve QP)
opts = optimoptions('quadprog','Algorithm','interior-point-convex', 'Display','off');
[x_opt, fval, exitflag] = quadprog(H, f, Aineq, bineq, Aeq, beq, [], [], [], opts);

if isempty(x_opt) || exitflag~=1
    % QP failed. Return zero torque to avoid NaN explosion.
    % tau = zeros(10,1);
    % flag = 1;
    x_opt = [0 0 80 0 0 80 0 0 80 0 0 80]';
end

Fc_opt = x_opt;
Fc_1 = Fc_opt(1:3);
Fc_2 = Fc_opt(4:6);
Fc_3 = Fc_opt(7:9);
Fc_4 = Fc_opt(10:12);

[J1f, J1b, J2f, J2b] = computeFootJacobians(s,model);

J1f_r = [zeros(10,6), eye(10)] * J1f';
J1b_r = [zeros(10,6), eye(10)] * J1b';
J2f_r = [zeros(10,6), eye(10)] * J2f';
J2b_r = [zeros(10,6), eye(10)] * J2b';

% take the linear component
tau = -(J1f_r(:,4:6) * Fc_1 + J1b_r(:,4:6) * Fc_2 + J2f_r(:,4:6) * Fc_3 + J2b_r(:,4:6) * Fc_4);
tau = tau + tau1;

end