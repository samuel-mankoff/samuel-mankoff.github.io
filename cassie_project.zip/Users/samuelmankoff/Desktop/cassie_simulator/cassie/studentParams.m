function params = studentParams(model)
% define any parameters here 
% params - struct

params = struct();

% Example: controller gains & desired COM/attitude
params.g      = 9.81;
params.mass   = total_mass(model);  % or total_mass(model) depending on struct

% COM PD gains
params.Kp_pos = 1000;
params.Kd_pos = 100;

% Orientation PD gains
params.Kp_ori = 1000;
params.Kd_ori = 5;

% Desired COM height & orientation
params.p_des      = [0; 0; 1.0006];
params.R_des      = eye(3);
params.omega_des  = zeros(3,1);

% You can also put joint PD gains here if you want:
params.Kp_joint = 500;
params.Kd_joint = 100;

end
